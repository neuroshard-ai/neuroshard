"""Run explicit, bounded NeuroShard model-evolution experiments."""
import argparse
import json
from pathlib import Path


def main():
    parser=argparse.ArgumentParser(description=__doc__,epilog='Experimental tools. These commands do not change the public testnet or issue spendable NEURO.')
    commands=parser.add_subparsers(dest='command',required=True)
    convert=commands.add_parser('import-model',help='Convert a local tied-weight Llama seed into verifiable components')
    convert.add_argument('--model-dir',type=Path,required=True)
    convert.add_argument('--objects',type=Path,required=True)
    grow=commands.add_parser('grow',help='Create an identity-initialized capacity candidate; does not promote it')
    grow.add_argument('--objects',type=Path,required=True)
    grow.add_argument('--model-root',required=True)
    grow.add_argument('--layers',type=int,default=4)
    audit=commands.add_parser('audit',help='Independently replay one committed worker step')
    audit.add_argument('--objects',type=Path,required=True)
    audit.add_argument('--trace-root',required=True)
    inspect=commands.add_parser('inspect',help='Show model size and assignments under explicit worker capacities')
    inspect.add_argument('--objects',type=Path,required=True)
    inspect.add_argument('--model-root',required=True)
    inspect.add_argument('--workers',type=int,default=3)
    args=parser.parse_args()
    from .objects import Objects
    store=Objects(args.objects)
    if args.command=='import-model':
        from .model import from_pretrained
        root,model=from_pretrained(args.model_dir,store)
        result={'model_root':root,'parameters':model['parameters']}
    elif args.command=='grow':
        from .model import grow
        root,model=grow(args.model_root,store,args.layers)
        result={'model_root':root,'parameters':model['parameters'],'status':'unevaluated_candidate'}
    elif args.command=='audit':
        from .worker import replay_trace
        result=replay_trace(store,args.trace_root)
    else:
        from .model import place
        model=store.json(args.model_root)
        result={'model_root':args.model_root,'parameters':model['parameters'],
                'assignments':place(model,[48000000]*args.workers)}
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
