"""The original licensed seed files, pinned independently of mutable repository names."""
MODEL_REPO = 'HuggingFaceTB/SmolLM2-135M-Instruct'
MODEL_REVISION = '12fd25f77366fa6b3b4b768ec3050bf629380bac'
FILES = {'config.json': '8eb740e8bbe4cff95ea7b4588d17a2432deb16e8075bc5828ff7ba9be94d982a', 'generation_config.json': '87b916edaaab66b3899b9d0dd0752727dff6666686da0504d89ae0a6e055a013', 'merges.txt': '0b54e8aa4e53d5383e2e4bc635a56b43f9647f7b13832d5d9ecd8f82dac4f510', 'model.safetensors': '5af571cbf074e6d21a03528d2330792e532ca608f24ac70a143f6b369968ab8c', 'special_tokens_map.json': '2b7379f3ae813529281a5c602bc5a11c1d4e0a99107aaa597fe936c1e813ca52', 'tokenizer.json': '9ca9acddb6525a194ec8ac7a87f24fbba7232a9a15ffa1af0c1224fcd888e47c', 'tokenizer_config.json': '4ec77d44f62efeb38d7e044a1db318f6a939438425312dfa333b8382dbad98df', 'vocab.json': '82b84012e3add4d01d12ba14442026e49b8cbbaead1f79ecf3d919784f82dc79'}


def verify(directory):
    import hashlib
    from pathlib import Path
    directory=Path(directory)
    for name,expected in FILES.items():
        hasher=hashlib.sha256()
        with (directory/name).open('rb') as source:
            for chunk in iter(lambda:source.read(1024*1024),b''):
                hasher.update(chunk)
        if hasher.hexdigest()!=expected:
            raise ValueError('Seed file differs from the published model revision: '+name)
